<?php $__env->startSection('content'); ?>

<link href="<?php echo e(asset('css/style1.css')); ?>" rel="stylesheet">
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Regístrate')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nombres')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="apellido" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Apellidos')); ?></label>

                            <div class="col-md-6">
                                <input id="apellido" type="text" class="form-control<?php echo e($errors->has('apellido') ? ' is-invalid' : ''); ?>" name="apellido" value="<?php echo e(old('apellido')); ?>" required autofocus>

                                <?php if($errors->has('apellido')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('apellido')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="sexo" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Sexo')); ?></label>

                            <div class="col-md-6">
                                <input name="sexo" type="radio" value="Femenino" required autofocus> &nbsp Femenino&nbsp 
                                <input name="sexo" type="radio" value="Masculino"  required autofocus>&nbsp Masculino &nbsp 
                                <input name="sexo" type="radio" value="Prefiero no especificar" required autofocus>&nbsp No especificar 
                                <?php if($errors->has('sexo')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('sexo')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                      <div class="form-group row">
                            <label for="fecha_nac" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Fecha de nacimiento')); ?></label>

                            <div class="col-md-6">
                               <input id="fecha_nac" type="date" value="fecha_nac" class="form-control<?php echo e($errors->has('fecha_nac') ? ' is-invalid' : ''); ?>" name="fecha_nac" value="<?php echo e(old('fecha_nac')); ?>" required autofocus>
                                <?php if($errors->has('fecha_nac')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('fecha_nac')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label for="provincia" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Provincia')); ?></label>

                            <div class="col-md-6">
                            <select name="departamento" value="<?php echo e(old('departamento')); ?>" required autofocus>
                                <option value="0" selected>Selecciona tu departamento</option> 
                                <option value="1" >Lima</option>
                                <option value="2">Callao</option><
                                <option value="3">La Libertad</option> 
                                 <option value="4">Piura</option>
                                <option value="5">Trujillo</option>
                                <option value="6">Lambayeque</option> 
                                 <option value="7">Ica</option>
                                <option value="8">Junín</option>
                                 <option value="9">Ancash</option> 
                                 <option value="10" >San Martín</option>
                                <option value="11">Puno</option>
                                <option value="12">Pasco</option>
                                <option value="13" >Tacna</option>
                                <option value="14">Tumbes</option>
                                <option value="15">Ucayali</option>
                            </select>   
                            
                                <?php if($errors->has('departamento')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('departamento')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        
                        <!-- celular -->
                        <div class="form-group row">
                            <label for="celular" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Celular')); ?></label>

                            <div class="col-md-6">
                                <input id="celular" type="text" class="form-control<?php echo e($errors->has('celular') ? ' is-invalid' : ''); ?>" name="celular" value="<?php echo e(old('name')); ?>" required autofocus>

                                <?php if($errors->has('celular')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('celular')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        
                        <!-- rol -->
                        <div class="form-group row">
                            <label for="rol" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Rol')); ?></label>

                            <div class="col-md-6">
                            <input name="rol" type="radio" value="persona" required autofocus> Persona&nbsp 
                            <input name="rol" type="radio" value="restaurante" required autofocus> Restaurante&nbsp 
                                <?php if($errors->has('rol')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('rol')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- correo -->
                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('contraseña')); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirmar constraseña')); ?></label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Registrarse')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\proyectos\laravel\sistema_restaurante\resources\views/auth/register.blade.php */ ?>