<?php echo e($slot); ?>: <?php echo e($url); ?>


<?php /* C:\xampp\htdocs\proyectos\laravel\sistema_restaurante\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php */ ?>