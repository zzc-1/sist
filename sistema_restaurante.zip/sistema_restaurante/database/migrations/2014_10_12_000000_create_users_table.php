<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('usuario', function (Blueprint $table) {
            $table->bigIncrements('id')->nullable();
            $table->string('name');
            $table->string('apellido');
            $table->enum('sexo',['Femenino', 'Masculino','Prefiero no escpecificar']);
            $table->date('fecha_nac');
            $table->enum('departamento',['sin seleccionar','Lima','Callao','La Libertad','Piura','Trujillo','Lambayeque','Ica','Junín','Ancash','San Martín','Puno','Pasco','Tacna','Tumbes','Ucayali']);
            $table->string('celular');
            $table->enum('rol',['persona','restaurante']);
            $table->string('email')->unique();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
